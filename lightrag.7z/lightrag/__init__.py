from .lightrag import LightRAG as LightRAG, QueryParam as QueryParam

__version__ = "1.3.6"
__author__ = "Zirui Guo"
__url__ = "https://github.com/HKUDS/LightRAG"
